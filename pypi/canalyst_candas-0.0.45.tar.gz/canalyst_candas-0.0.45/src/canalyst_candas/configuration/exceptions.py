"""
Exceptions for config module
"""


class ConfigException(Exception):
    """
    Config is incorrect and/or missing
    """
