"""
Store SDK version
"""
__version__ = "0.0.35"
