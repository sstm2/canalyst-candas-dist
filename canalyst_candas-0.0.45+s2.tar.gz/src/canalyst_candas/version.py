"""
Store SDK version
"""
__version__ = "0.0.45+s2"
