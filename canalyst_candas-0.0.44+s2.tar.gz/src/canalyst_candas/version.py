"""
Store SDK version
"""

__version__ = "0.0.44+s2"
